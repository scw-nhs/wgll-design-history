<?php
/**
 * The template for displaying single 'Search page' posts
 * Template Name: Search Page Template
 * Template Post Type: search-page
 */

get_header(); ?>

<div class="nhsuk-width-container">
  <div class="nhsuk-grid-row">
    <div class="nhsuk-grid-column-one-quarter">
      <?php get_sidebar(); ?>
    </div>
    <div class="nhsuk-grid-column-three-quarters">
      <?php
        if ( have_posts() ) :
          while ( have_posts() ) : the_post();
            the_content();
          endwhile;
        endif;
      ?>
    </div>
  </div>
</div>

<?php get_footer(); ?>