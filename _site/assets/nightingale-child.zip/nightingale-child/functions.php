<?php
/**
 * Enqueue parent and child styles.
 */
add_action( 'wp_enqueue_scripts', function () {
    // Load parent theme stylesheet first.
    wp_enqueue_style(
        'nightingale-parent',
        get_template_directory_uri() . '/style.css',
        array(),
        wp_get_theme( get_template() )->get( 'Version' )
    );

    // And then child stylesheet.
    wp_enqueue_style(
        'nightingale-child',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'nightingale-parent' ),
        wp_get_theme()->get( 'Version' )
    );
} );
