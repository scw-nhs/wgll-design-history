<?php
/**
 * Cleaned tabs partial: safe, admin-friendly, and Nightingale-compatible
 *
 * Purpose:
 *  - Render a "Pages in this section" navigation for a parent page (overview) and
 *    its child pages (or, when on a child page, the parent as overview + siblings).
 *  - Avoids emitting output in wp-admin/AJAX/REST (prevents header/redirect issues when saving posts).
 *  - Uses proper escaping and does not include a closing PHP tag (avoids stray output/BOM).
 *
 * Usage options:
 *  1) Include this file in your template and let it echo automatically on the front-end.
 *     Example in a template:  include get_template_directory() . '/partials/tabs.php';
 *
 *  2) Call the rendering function directly where you want the nav to appear:
 *        echo scw_render_section_tabs();
 *     or   echo scw_render_section_tabs( $post_id );
 *
 * Filters provided:
 *  - scw_tabs_overview_label  (string)   Default "Overview" label text.
 *  - scw_tabs_query_args      (array)    Amend the WP_Query args for children/siblings.
 */

// -----------------------------------------------------------------------------
// Guard: never output or run heavy logic in admin, AJAX or REST contexts
// -----------------------------------------------------------------------------
if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    // Define a no-op shim so templates can call the function safely in admin previews.
    if ( ! function_exists('scw_render_section_tabs') ) {
        function scw_render_section_tabs( $post_id = 0 ) { return ''; }
    }
    return;
}

if ( ! function_exists('scw_render_section_tabs') ) :
/**
 * Render the “Pages in this section” navigation for the current page hierarchy.
 *
 * @param int $post_id Optional. A specific page ID. Defaults to current global post ID.
 * @return string HTML markup (does not echo).
 */
function scw_render_section_tabs( $post_id = 0 ) {
    $post_id = $post_id ? absint( $post_id ) : get_the_ID();
    if ( ! $post_id ) return '';

    $current = get_post( $post_id );
    if ( ! $current || 'page' !== $current->post_type ) return '';

    // Work out the parent context
    $is_overview = empty( $current->post_parent );
    $parent_id   = $is_overview ? (int) $current->ID : (int) $current->post_parent;

    // Labels
    $overview_label = apply_filters( 'scw_tabs_overview_label', __( 'Overview', 'nightingale' ) );

    // Section title for ARIA label
    $section_title = get_the_title( $parent_id );
    if ( '' === trim( (string) $section_title ) ) {
        $section_title = __( 'Pages in this section', 'nightingale' );
    }

    // Query args for children/siblings with a toggle via meta key 'tabbed-page' == 'on'
    $args = array(
        'post_type'              => 'page',
        'post_parent'            => $parent_id,
        'orderby'                => 'menu_order',
        'order'                  => 'ASC',
        'post_status'            => 'publish',
        'posts_per_page'         => -1,
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'meta_query'             => array(
            array(
                'key'   => 'tabbed-page',
                'value' => 'on',
            ),
        ),
    );
    $args = apply_filters( 'scw_tabs_query_args', $args );

    $q = new WP_Query( $args );

    // If there are no children and we are on a child page, still show the Overview only.
    $has_children = $q->have_posts();

    // Build markup
    ob_start();

    // Wrapper nav – keep classes minimal; theme styles can target .scw-section-tabs
    ?>
    <nav class="scw-section-tabs nhsuk-u-margin-bottom-4" aria-label="<?php echo esc_attr( sprintf( __( 'Pages in this section: %s', 'nightingale' ), $section_title ) ); ?>">
      <ul class="nhsuk-list nhsuk-list--border nhsuk-u-margin-bottom-0">
        <?php
        // Overview item always first
        $overview_url   = get_permalink( $parent_id );
        $overview_title = get_post_meta( $parent_id, 'tabname', true );
        if ( '' === trim( (string) $overview_title ) ) {
            $overview_title = get_the_title( $parent_id );
            if ( '' === trim( (string) $overview_title ) ) {
                $overview_title = $overview_label; // last resort
            }
        }

        $overview_is_current = ( $post_id === $parent_id );
        ?>
        <li class="nhsuk-list__item">
          <a class="nhsuk-link" href="<?php echo esc_url( $overview_url ); ?>"<?php echo $overview_is_current ? ' aria-current="page"' : ''; ?>>
            <?php echo esc_html( $overview_title ); ?>
          </a>
        </li>

        <?php if ( $has_children ) :
            while ( $q->have_posts() ) : $q->the_post();
                $child_id   = get_the_ID();
                $child_url  = get_permalink( $child_id );
                $child_name = get_post_meta( $child_id, 'tabname', true );
                if ( '' === trim( (string) $child_name ) ) {
                    $child_name = get_the_title( $child_id );
                }
                $is_current = ( $child_id === $post_id );
                ?>
                <li class="nhsuk-list__item">
                  <a class="nhsuk-link" href="<?php echo esc_url( $child_url ); ?>"<?php echo $is_current ? ' aria-current="page"' : ''; ?>>
                    <?php echo esc_html( $child_name ); ?>
                  </a>
                </li>
            <?php endwhile; wp_reset_postdata(); endif; ?>
      </ul>
    </nav>
    <?php

    return trim( ob_get_clean() );
}
endif; // function exists

// -----------------------------------------------------------------------------
// Auto-echo when this file is included on the front end (keeps legacy behaviour)
// -----------------------------------------------------------------------------
if ( ! is_admin() && ! wp_doing_ajax() && ! ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    echo scw_render_section_tabs();
}

// No closing PHP tag.
